from mrjob.job import MRJob

# Importing necessary library to define multistep job.
from mrjob.step import MRStep

# We extend the MRJob class 
# This includes our definition of map and reduce functions
class MyMapReduce(MRJob):

    # Defining two step jobs.
    def steps(self):
        return  [
            MRStep (mapper=self.mapper,
                    reducer=self.reducer),
            MRStep(reducer=self.count_flights)
            ]


    # Our mapper takes a fragment of text as an input and produces a list of (key, value), where value is the length
    # Yielding all the origin and destination pair as keys. And 1 as value for each pair.
    def mapper(self, _, line):
        pair = line.split(",")
        if pair[17] != "Origin":
            yield ((pair[17], pair[18]), 1)

    # Produces value as 1 for each unique origin, destination pair. Key is set as none for every pair.
    def reducer(self, pair, value):
        yield(None, 1)

    # Counts or sums up values of all the key-value pairs to get the final result.
    def count_flights(self, pair, value):
        yield ("Total Unique flights: ", sum(value))


if __name__ == '__main__':
    MyMapReduce.run()

""" Command:
python question_4.py input > out.txt

"""