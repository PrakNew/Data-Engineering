
from itertools import count
from mrjob.job import MRJob

# We extend the MRJob class 
# This includes our definition of map and reduce functions
class MyMapReduce(MRJob):

    # Our mapper takes a fragment of text as an input and produces a list of (key, value) pair.
    # The key is a 'year' and the value is 1, indicating a player has scored a century (>99).
    def mapper(self, _, line):
        words = line.split(",")
        year = words[3][-4:]
        country = words[0] 
        if (words[2] != "Runs") and (int(words[2].strip()) >99) and (country == "India"):
            yield (year, 1)

    # Our reducer takes a group of (key, value) where key = year, and produces a final (key, value) pair.
    # The key is the year and its value is the sum of centuries made by all the players in that year.
    def reducer(self, year, value):
        yield(year, sum(value))


# 
if __name__ == '__main__':
    MyMapReduce.run()

"""
python question_7.py input > out.txt
"""