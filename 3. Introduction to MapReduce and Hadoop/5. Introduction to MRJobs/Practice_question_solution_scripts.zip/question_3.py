from mrjob.job import MRJob
import re

# Regular expression that finds all the words in a String
WORD_REGEX = re.compile(r"\b\w+\b")


# We extend the MRJob class 
# This includes our definition of map and reduce functions
class MyMapReduce(MRJob):

    # Our mapper takes a fragment of text as an input and produces a list of (key, value), where value is the length
    # Only if the length is greater than a predefined value (14)
    def mapper(self, _, line):
        words = WORD_REGEX.findall(line)
        for word in words:
            if len(word) > 14:
                yield(word, len(word))

    # The reducer produces only one instance of each word
    def reducer(self, word, length):
        yield(word, len(word))


if __name__ == '__main__':
    MyMapReduce.run()

""" Command:
python question_3.py input > out.txt
"""