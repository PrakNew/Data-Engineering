
from itertools import count
from mrjob.job import MRJob
import re

# Regular expression that finds all the words in a String
WORD_REGEX = re.compile(r"\b\w+\b")


# We extend the MRJob class 
# This includes our definition of map and reduce functions
class MyMapReduce(MRJob):

    # Our mapper takes a fragment of text as an input and produces a list of (key, value) 
    # The key is the name of the player and value is 1 if the run is more than or equal to 100 (>99).
    def mapper(self, _, line):
        words = line.split(",")
        if (words[2] != "Runs") and (int(words[2].strip()) >99):
            yield (words[1], 1)

    # Our reducer takes a group of (key, value) where key = player_name, and produces a final (key, value) pair.
    # The key is a player_name and its value is the number of centuries (or more) he has made.
    def reducer(self, player, runs):
        yield(player, sum(runs))


# 
if __name__ == '__main__':
    MyMapReduce.run()

"""
python question_6.py input > out.txt
"""