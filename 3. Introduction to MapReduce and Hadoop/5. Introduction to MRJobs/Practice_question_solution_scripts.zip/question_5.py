from mrjob.job import MRJob
from mrjob.step import MRStep
import re

# Regular expression that finds all the words in a String
WORD_REGEX = re.compile(r"\b\w+\b")


# We extend the MRJob class 
# This includes our definition of map and reduce functions
class MyMapReduce(MRJob):

    # Our mapper takes a fragment of text as an input and produces a list of (key, value)
    # key is the origin and value is set as 1 for each pair.
    def mapper(self, _, line):
        org = line.split(",")
        if (org[17] != "Origin") and (org[1] == "2004"):
            yield (org[17], 1)

    # The reducer produces only one instance of each origin and sums up the number of similar keys.
    def reducer(self, org, value):
        yield(org , sum(value))


if __name__ == '__main__':
    MyMapReduce.run()

""" Command:
python question_5.py input > out.txt

"""