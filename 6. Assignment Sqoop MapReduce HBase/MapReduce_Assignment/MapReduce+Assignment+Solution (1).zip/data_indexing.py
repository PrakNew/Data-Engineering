import os
import glob
import pandas as pd

input_path = '/home/hadoop/input'
os.chdir(input_path)
extension = 'csv'
raw_filenames = [i for i in glob.glob('*')]   ### len(all_filenames1)
csv_filenames = ['%s'%(i).format(extension) for i in raw_filenames]
# print(len(csv_filenames))
# print(type(raw_filenames[0]))
# print(csv_filenames[1])

for i in csv_filenames:
    df = pd.read_csv(i)
    df['index'] = range(1, len(df) + 1)
    df.set_index('index', inplace = True)
    new_file_name = 'c'+i
    print('Converting File' + i)
    df.to_csv(new_file_name)
