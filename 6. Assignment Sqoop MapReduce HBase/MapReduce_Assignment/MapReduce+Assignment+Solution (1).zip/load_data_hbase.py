"""
Insert data into HBase with a Python script.
% hbase shell commands to test the codes
hbase> create "yellow_taxi", "VendorID", "tpep_pickup_datetime", "tpep_dropoff_datetime","passenger_count", "trip_distance", "RatecodeID", "store_and_fwd_flag", "PULocationID", "DOLocationID", "payment_type", "fare_amount", "extra", "mta_tax", "tip_amount", "tolls_amount", "improvement_surcharge", "total_amount",  "congestion_surcharge", "airport_fee"
"""

import csv
import happybase
import time

batch_size = 1000
host = "0.0.0.0"
file_path = "cyellow_tripdata_2017-01.csv"
row_count = 0
start_time = time.time()
table_name = "yellow_taxi"


def connect_to_hbase():
    """ Connect to HBase server.
    This will use the host, namespace, table name, and batch size as defined in the global variables above.
    """
    conn = happybase.Connection(host = host)
    conn.open()
    table = conn.table(table_name)
    batch = table.batch(batch_size = batch_size)
    return conn, batch


def insert_row(batch, row):
    """ Insert a row into HBase.
    Write the row to the batch. When the batch size is reached, rows will be sent to the database.
    """
    batch.put(row[0], {"VendorID:VendorID": row[1], "tpep_pickup_datetime:tpep_pickup_datetime": row[2], "tpep_dropoff_datetime:tpep_dropoff_datetime": row[3], "passenger_count:passenger_count": row[4],
        "trip_distance:trip_distance": row[5], "RatecodeID:RatecodeID": row[6], "store_and_fwd_flag:store_and_fwd_flag": row[7],
        "PULocationID:PULocationID": row[8], "DOLocationID:DOLocationID": row[9], "payment_type:payment_type": row[10],
        "fare_amount:fare_amount": row[11], "extra:extra": row[12], "mta_tax:mta_tax": row[13],"tip_amount:tip_amount": row[14],
        "tolls_amount:tolls_amount": row[15],"improvement_surcharge:improvement_surcharge": row[16],"total_amount:total_amount": row[17],
        "congestion_surcharge:congestion_surcharge": row[18],"airport_fee:airport_fee": row[19]})

def read_csv():
    csvfile = open(file_path, "r")
    csvreader = csv.reader(csvfile)
    return csvreader, csvfile


# After everything has been defined, run the script.
conn, batch = connect_to_hbase()
csvreader, csvfile = read_csv()

try:
    # Loop through the rows. The first row contains column headers, so skip that
    # row. Insert all remaining rows into the database.
    for row in csvreader:
        row_count += 1
        if row_count == 1:
            pass
        else:
            insert_row(batch, row)

    # If there are any leftover rows in the batch, send them now.
    batch.send()
finally:
    # No matter what happens, close the file handle.
    csvfile.close()
    conn.close()

duration = time.time() - start_time