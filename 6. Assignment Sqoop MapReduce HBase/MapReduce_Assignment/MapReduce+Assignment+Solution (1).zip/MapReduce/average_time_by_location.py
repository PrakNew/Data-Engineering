from mrjob.job import MRJob
from mrjob.step import MRStep
import datetime
class average_time_by_location(MRJob):
  def steps(self):
    return [MRStep(mapper=self.mapper_extract_values, reducer=self.reducer_average_time)]
  
  def mapper_extract_values(self, _, line):
    line = line.strip()
    if len(line) > 1:
      vals = line.split(",") # split the results using ","
      # Remove the header
      if vals[0] != "VendorID" and vals[0] != "":
        PULocationID = vals[7]
        tpep_pickup_datetime = vals[1]
        tpep_dropoff_datetime = vals[2]
        # pickuptime = tpep_pickup_datetime.split(' ')[1]
        # dropofftime = tpep_dropoff_datetime.split(' ')[1]
        pickuptime = datetime.datetime.strptime(tpep_pickup_datetime,'%Y-%m-%d %H:%M:%S')
        dropofftime = datetime.datetime.strptime(tpep_dropoff_datetime,'%Y-%m-%d %H:%M:%S')
        trip_time = dropofftime - pickuptime
        # month = tpep_pickup_datetime.split('-')[1]
        yield (PULocationID, trip_time.seconds)
    
  def reducer_average_time(self, PULocationID, time):
    s = 0 # count
    c = 0 # number
    for p in time:
        s += p
        c += 1
    yield PULocationID, (s/c)

if __name__ == '__main__':
  average_time_by_location.run()