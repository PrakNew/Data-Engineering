# Count the number of vendors in the dataset
from mrjob.job import MRJob
from mrjob.step import MRStep

class newcode(MRJob):
  def mapper(self, _, line):
    line = line.strip()
    if len(line) > 1:
      vals = line.split(",") # split the results using ","
      # Remove the header
      if vals[0] != "VendorID" and vals[0] != "":
        vendorID = vals[0] # Look up the row mentioned
        yield vendorID, 1


  def reducer(self, vendorID, occurences):
   yield vendorID, sum(occurences)
  
  def steps(self):
    return[MRStep(mapper= self.mapper,reducer = self.reducer)]

if __name__ == '__main__':
  newcode.run()
