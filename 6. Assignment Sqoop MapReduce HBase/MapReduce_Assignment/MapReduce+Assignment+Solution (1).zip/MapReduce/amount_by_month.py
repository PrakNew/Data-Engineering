from mrjob.job import MRJob
from mrjob.step import MRStep

class SpendByCustomerSorted(MRJob):
  def steps(self):
    return [MRStep(mapper=self.mapper_get_values,reducer=self.reducer_totals_by_vendor),
            MRStep(mapper=self.mapper_make_amounts_key,reducer=self.reducer_output_results)]

  def mapper_get_values(self, _, line):
        line = line.strip()
        if len(line) > 1:
            vals = line.split(",") # split the results using ","
            if vals[0] != "VendorID" and vals[0] != "":
               vendorID = vals[0]
               orderAmount = float(vals[16])
               tpep_pickup_datetime = vals[1] # Look up the row mentioned
               month = tpep_pickup_datetime.split('-')[1]
               yield month, orderAmount

  def reducer_totals_by_vendor(self, month, orderAmount):
     yield month, sum(orderAmount)

  def mapper_make_amounts_key(self, month, orderAmount):
     yield '%04.02f'%float(orderAmount), month
        
  def reducer_output_results(self, Total, month):
     for months in month:
        yield months, Total

if __name__ == '__main__':
  SpendByCustomerSorted.run()