from mrjob.job import MRJob
from mrjob.step import MRStep
class payment_types_sorted(MRJob):
    def steps(self):
        return [MRStep(mapper=self.mapper_extract_values,combiner=self.combine_pay_counts,reducer=self.reducer_sum_pay_counts),
           MRStep(reducer=self.reduce_sort_counts)]
  
    def mapper_extract_values(self, _, line):
       line = line.strip()
       if len(line) > 1:
          vals = line.split(",") # split the results using ","
          # Remove the header
          if vals[0] != "VendorID" and vals[0] != "":
             payment_type = vals[9] # Look up the row mentioned
             yield payment_type, 1
	
    def combine_pay_counts(self, payment_type, values):
       yield payment_type, sum(values)

    def reducer_sum_pay_counts(self, payment_type, values):
       yield None, (sum(values), payment_type)

    def reduce_sort_counts(self, _, values):
       payment_type_map = {'1':'Credit Card', '2':'Cash', '3':'No Charge','4':'Dispute','5':'Unknown','6':'Voided Trip'}
       for count, payment in sorted(values, reverse=True):
          # yield ('%04.02f'%float(count), payment_type_map[payment])
          yield (payment_type_map[payment], '%04.02f'%float(count))


if __name__ == '__main__':
  payment_types_sorted.run()