from mrjob.job import MRJob
from mrjob.step import MRStep
from datetime import datetime

class trips_by_day_sorted(MRJob):
  def steps(self):
    return [MRStep(mapper=self.mapper_extract_values, 
                   combiner=self.combine_revenue_counts, 
                   reducer=self.reducer_revenue_counts),
            MRStep(reducer=self.reduce_sort_vaules)]
  
  def mapper_extract_values(self, _, line):
  # Get hour from the given date time string.
    def get_hour(date_time):
      return datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S').hour

  # Get day of week from the given date time string.
    def get_day(date_time):
      return datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S').weekday()

  # Strips date from the given date time string as Y-m-d.
    def get_date(date_time):
      return datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S').date()

    line = line.strip()
    if len(line) > 1:
      vals = line.split(",") # split the results using ","
      # Remove the header
      if vals[0] != "VendorID" and vals[0] != "":
        payment_type = vals[9] # Look up the row mentioned
        revenue = float(vals[16])
        tpep_pickup_datetime = vals[1] # Look up the row mentioned
        month = tpep_pickup_datetime.split('-')[1]
        hour =  get_hour(tpep_pickup_datetime)
        day = get_day(tpep_pickup_datetime)
        date = get_date(tpep_pickup_datetime)
        yield day, revenue
	
  def combine_revenue_counts(self, day, revenue):
    yield day, sum(revenue)

  def reducer_revenue_counts(self, day, revenue):
    yield None, (sum(revenue), day)

  def reduce_sort_vaules(self, _, values):
    # day_map = {'0':'Monday', '1':'Tuesday', '2':'Wednesday','3':'Thursday','4':'Friday','5':'Saturday','6':'Sunday'}
    for revenue, day in sorted(values, reverse=True):
      # yield ('%04.02f'%float(count), payment_type_map[payment])
      yield (day, '%04.02f'%float(revenue))

if __name__ == '__main__':
  trips_by_day_sorted.run()